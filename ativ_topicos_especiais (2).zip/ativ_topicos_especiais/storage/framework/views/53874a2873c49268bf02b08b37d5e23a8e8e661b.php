<?php $__env->startSection('content'); ?>
    <div class="container">
        <h1>Bem-vindo ao AdminLTE no Laravel!</h1>
        <p>Este é o conteúdo da página de boas-vindas usando o layout AdminLTE.</p>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\carlo\Desktop\xampp\htdocs\ativ_topicos_especiais\resources\views/welcome.blade.php ENDPATH**/ ?>