<div class="componente1">
    <h1> Olá </h1>
    <!-- Adicione mais HTML e Livewire components aqui -->
</div>
<?php /**PATH C:\Users\carlo\Desktop\xampp\htdocs\ativ_topicos_especiais\resources\views/components/componente1.blade.php ENDPATH**/ ?>