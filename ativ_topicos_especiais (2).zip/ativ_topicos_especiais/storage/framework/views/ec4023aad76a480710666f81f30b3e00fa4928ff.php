<!-- resources/views/annotations.blade.php -->


<?php $__env->startSection('content'); ?>
    <div class="container">
        <h1 class="my-4">Cadastro de Livros</h1>
        
        <!-- Mensagem de Sucesso -->
        <?php if(session('success')): ?>
            <div class="alert alert-success">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>
        
        <!-- Formulário de Cadastro de Livros -->
        <form action="<?php echo e(route('annotations.store')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label for="title">Título do Livro:</label>
                <input type="text" id="title" name="title" class="form-control" required>
            </div>
            
            <div class="form-group">
                <label for="author">Autor:</label>
                <input type="text" id="author" name="author" class="form-control" required>
            </div>
            
            <div class="form-group">
                <label for="genre">Gênero:</label>
                <input type="text" id="genre" name="genre" class="form-control" required>
            </div>
            
            <div class="form-group">
                <label for="year">Ano de Publicação:</label>
                <input type="number" id="year" name="year" class="form-control" required>
            </div>
            
            <div class="form-group">
                <label for="description">Descrição:</label>
                <textarea id="description" name="description" class="form-control" rows="4" required></textarea>
            </div>
            
            <button type="submit" class="btn btn-primary">Cadastrar Livro</button>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\carlo\Desktop\xampp\htdocs\ativ_topicos_especiais\resources\views/annotations.blade.php ENDPATH**/ ?>