<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $__env->yieldContent('title', 'AdminLTE Dashboard'); ?></title>
    <!-- Estilos CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('admin-lte/css/adminlte.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('admin-lte/css/all.min.css')); ?>">
</head>
<body class="hold-transition sidebar-mini">
    <div class="wrapper">
        <!-- Navbar -->
        <nav class="main-header navbar navbar-expand navbar-white navbar-light">
            <!-- Navbar content here -->
        </nav>

        <!-- Main Sidebar Container -->
        <aside class="main-sidebar sidebar-dark-primary elevation-4">
            <!-- Sidebar content here -->
        </aside>

        <!-- Content Wrapper. Contains page content -->
        <div class="content-wrapper">
            <!-- Content Header (Page header) -->
            <div class="content-header">
                <?php echo $__env->yieldContent('content-header'); ?>
            </div>

            <!-- Main content -->
            <section class="content">
                <?php echo $__env->yieldContent('content'); ?>
            </section>
            <!-- /.content -->
        </div>
        <!-- /.content-wrapper -->

        <!-- Main Footer -->
        <footer class="main-footer">
            <!-- Footer content here -->
        </footer>
    </div>
    <!-- ./wrapper -->

    <!-- Scripts -->
    <script src="<?php echo e(asset('admin-lte/js/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('admin-lte/js/bootstrap.bundle.min.js')); ?>"></script>
    <script src="<?php echo e(asset('admin-lte/js/adminlte.min.js')); ?>"></script>
</body>
</html><?php /**PATH C:\Users\carlo\Desktop\xampp\htdocs\ativ_topicos_especiais\resources\views/layouts/app.blade.php ENDPATH**/ ?>