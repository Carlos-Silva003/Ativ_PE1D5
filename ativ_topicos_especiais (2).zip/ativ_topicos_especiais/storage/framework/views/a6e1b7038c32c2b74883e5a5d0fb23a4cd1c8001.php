<footer class="main-footer">
    <strong>Copyright &copy; 2024 <a href="#">AdminLTE</a>.</strong>
    All rights reserved.
</footer>
<?php /**PATH C:\Users\carlo\Desktop\xampp\htdocs\ativ_topicos_especiais\resources\views/layouts/footer.blade.php ENDPATH**/ ?>