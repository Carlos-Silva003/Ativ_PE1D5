@extends('layouts.app')

@section('content')

@component('components.componente1')
@endcomponent
@endsection