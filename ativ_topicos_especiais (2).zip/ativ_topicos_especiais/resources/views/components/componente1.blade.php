<div class="componente1">
    <h1> Olá </h1>
    <!-- Adicione mais HTML e Livewire components aqui -->
</div>
