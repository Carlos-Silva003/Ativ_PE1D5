@extends('layouts.app')

@section('content')
    <div class="container">
        @livewire('componente1')
    </div>
@endsection
