<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Annotation; // Supondo que você tenha um modelo Annotation

class AnnotationController extends Controller
{
    // Método para exibir o formulário
    public function create()
    {
        return view('annotations');
    }

    // Método para armazenar os dados do formulário
    public function store(Request $request)
    {
        // Validação dos dados do formulário
        $request->validate([
            'title' => 'required|string|max:255',
            'author' => 'required|string|max:255',
            'genre' => 'required|string|max:255',
            'year' => 'required|integer|between:1000,9999',
            'description' => 'required|string',
        ]);

        // Armazenar os dados no banco de dados
        Annotation::create([
            'title' => $request->title,
            'author' => $request->author,
            'genre' => $request->genre,
            'year' => $request->year,
            'description' => $request->description,
        ]);

        // Redirecionar com mensagem de sucesso
        return redirect()->route('annotations.create')->with('success', 'Livro cadastrado com sucesso!');
    }
}
