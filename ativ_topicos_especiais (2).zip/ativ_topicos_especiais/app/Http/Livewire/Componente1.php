<?php

namespace App\Http\Livewire;

use Livewire\Component;

class Componente1 extends Component
{
    public $message = 'Olá, Livewire!';
    public function render()
    {
        return view('livewire.componente1');
    }
}
