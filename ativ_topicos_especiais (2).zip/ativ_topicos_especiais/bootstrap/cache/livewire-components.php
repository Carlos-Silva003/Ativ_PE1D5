<?php return array (
  'componente1' => 'App\\Http\\Livewire\\Componente1',
);