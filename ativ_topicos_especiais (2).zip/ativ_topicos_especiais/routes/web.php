<?php

use Illuminate\Support\Facades\Route;

// Rota para a página inicial
Route::get('/', function () {
    return view('home');
})->name('home');

// Rota para a página de feedback (anotações)
Route::get('/annotations', function () {
    return view('annotations');
})->name('annotations.index');

// Rota para processar o formulário de feedback (anotações)
Route::post('/annotations', [App\Http\Controllers\BookController::class, 'store'])->name('annotations.store');

use App\Http\Controllers\AnnotationController;

Route::get('annotations/create', [AnnotationController::class, 'create'])->name('annotations.create');
Route::post('annotations', [AnnotationController::class, 'store'])->name('annotations.store');
